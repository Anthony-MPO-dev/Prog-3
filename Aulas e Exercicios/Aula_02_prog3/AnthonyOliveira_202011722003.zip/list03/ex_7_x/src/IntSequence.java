public interface IntSequence{
    int next();// retorna o próximo inteiro da sequencia 
    boolean hasNext();//true se há um próximo elemento na sequencia
}