public interface Mensuravel {
    public double getMedida();
}
